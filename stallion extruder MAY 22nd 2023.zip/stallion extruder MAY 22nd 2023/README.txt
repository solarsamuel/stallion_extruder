The enclosed works contain details on how to build the Stallion Extruder. 

Enclosed are details in regards to parts, pictures, assemblies, schematics, firmware, sourcing, and know-how. 

License - The enclosed works are free for individuals. We charge companies a 5% licensing fee on revenue to use the enclosed works. 